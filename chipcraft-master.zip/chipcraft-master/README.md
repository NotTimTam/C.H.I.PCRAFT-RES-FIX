![alt tag](https://i.imgur.com/orlCPcj.png "CHIPCRAFT")  
![alt tag](https://i.imgur.com/HZMyVR0.jpg "ON CHIP FOR REALZ")  
Scripts to build shims, download and install Minecraft Pi Edition on CHIP & PocketCHIP.

Includes the amazing work of @xobs - https://github.com/xobs/mcrpi-wrapper

With EGL context hints from @thp - https://github.com/thp/eglo

Building requires
----
build-essential
git
libsdl1.2-dev

License
----
Public Domain






